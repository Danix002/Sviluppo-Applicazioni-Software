package catering.businesslogic.event;

public class EventException extends Exception {
    public EventException() {
    }

    public EventException(String s) {
        super(s);
    }
}
