package catering.businesslogic.ShiftBoard;

public class ShiftBoardManager {

}
