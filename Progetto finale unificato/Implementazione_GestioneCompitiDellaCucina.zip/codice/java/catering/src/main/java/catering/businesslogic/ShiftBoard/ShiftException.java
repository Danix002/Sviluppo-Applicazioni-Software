package catering.businesslogic.ShiftBoard;

public class ShiftException extends Exception {
    public ShiftException() {
    }

    public ShiftException(String s) {
        super(s);
    }
}
