package catering.businesslogic.task;

public class SummarySheetException extends Exception {
    public SummarySheetException() {
    }

    public SummarySheetException(String s) {
        super(s);
    }
}
