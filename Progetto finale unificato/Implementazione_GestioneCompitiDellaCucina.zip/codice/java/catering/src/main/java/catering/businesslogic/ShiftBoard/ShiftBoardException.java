package catering.businesslogic.ShiftBoard;

public class ShiftBoardException extends Exception {
    public ShiftBoardException() {
    }

    public ShiftBoardException(String s) {
        super(s);
    }
}
