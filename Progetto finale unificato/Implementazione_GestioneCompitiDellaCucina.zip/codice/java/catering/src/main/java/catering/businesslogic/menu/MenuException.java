package catering.businesslogic.menu;

public class MenuException extends Exception {
    public MenuException() {
    }

    public MenuException(String s) {
        super(s);
    }
}
