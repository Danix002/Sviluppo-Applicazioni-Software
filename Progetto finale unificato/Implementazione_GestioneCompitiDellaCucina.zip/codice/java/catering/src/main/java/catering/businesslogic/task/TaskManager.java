package catering.businesslogic.task;

public class TaskManager {
    
}
