package catering.businesslogic.event;

public class Penal {
    
    private String motivation;

    public Penal(String motivation) {
        this.motivation = motivation;
    }

    public String getMotivation() {
        return this.motivation;
    }
}
